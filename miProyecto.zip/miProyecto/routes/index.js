var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/clase1', function(req, res, next) {
  res.render('clase1');
});

router.get('/mercadoliebre', function(req, res, next) {
  res.render('mercadoliebre');
});

router.get('/registro', function(req, res, next) {
  res.render('registro');
});

router.get('/ingreso', function(req, res, next) {
  res.render('ingreso');
});

module.exports = router;
